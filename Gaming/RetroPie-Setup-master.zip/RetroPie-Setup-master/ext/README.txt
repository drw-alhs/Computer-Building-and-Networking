You can checkout additional repositories here to add 3rd party modules.

Repositories should be structured so you have:

ext/REPOSITORY_NAME/scriptmodules

Modules are only read from the following subfolders of scriptmodules:
 * emulators
 * libretrocores
 * ports
 * supplementary
 * admin

