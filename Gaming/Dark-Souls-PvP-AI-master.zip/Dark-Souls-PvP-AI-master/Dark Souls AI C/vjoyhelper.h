#ifndef VJOYHELPER_H
#define VJOYHELPER_H

#include "HelperUtil.h"

void ResetVJoyController();

#endif